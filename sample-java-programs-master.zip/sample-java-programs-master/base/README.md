Base module for Sample Applications
===================================

This module helps to write sample applications quickly by implementing
`com.github.chrishantha.sample.base.SampleApplication` interface and registering the implementation class as a service
in `META-INF/services/com.github.chrishantha.sample.base.SampleApplication`
